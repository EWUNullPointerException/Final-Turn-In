Install SWT from http://download.eclipse.org/eclipse/downloads/drops4/R-4.3.2-201402211700/#SWT as per the instructions at https://www.eclipse.org/swt/eclipse.php

Download the SQLite JDBC version 3.7.2.jar from https://bitbucket.org/xerial/sqlite-jdbc/downloads and include it in the projects external libraries.

Compile and run as a normal java project.
